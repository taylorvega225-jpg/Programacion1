
package Concesionario;


public class Main {
    public static void main(String[] args) {
        
        Empleado empleado = new Empleado("Diego", "Moreno", 1875000);
        Auto auto1 = new Auto( "Tesla" ,1 );
        Auto auto2 = new Auto( "Ford" ,2 );
        
        empleado.getAutosVendidos().add(auto1);
        empleado.getAutosVendidos().add(auto2);
        
        
         double nominaFinal = Empleado.calcularMiNomina(empleado);
         
         System.out.println("Nombre del empleado: "+empleado.getNombre() +" "+ empleado.getApellido() );
         System.out.println("El valor de la nomina: " + nominaFinal);
        
        
        
        
        
        
    }
    
}
