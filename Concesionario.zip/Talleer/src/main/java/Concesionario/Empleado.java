
package Concesionario;

import java.util.ArrayList;

public class Empleado {
    private int id;
    private String nombre;
    private String apellido;
    private ArrayList <Auto> autosVendidos = new ArrayList<>();
    private int salario;

    public Empleado(String nombre, String apellido, int salario) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.salario = salario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public ArrayList<Auto> getAutosVendidos() {
        return autosVendidos;
    }

    public void setAutosVendidos(ArrayList<Auto> autosVendidos) {
        this.autosVendidos = autosVendidos;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    
     
    public static double calcularMiNomina(Empleado empleado) {
        double comisiones = 0;
        for (Auto auto : empleado.getAutosVendidos()) {
            if (auto.getTipo() == 1) {
                comisiones += 750000;                
            } else if (auto.getTipo() == 2) {
                comisiones += 500000;                
            } else if (auto.getTipo() == 3) {
                comisiones += 350000;
                
            }
        }
        double totalGanado = empleado.getSalario() + comisiones;
        double descuentos = totalGanado * 0.08;
        return totalGanado - descuentos;
        
    }
    
    
}

    

